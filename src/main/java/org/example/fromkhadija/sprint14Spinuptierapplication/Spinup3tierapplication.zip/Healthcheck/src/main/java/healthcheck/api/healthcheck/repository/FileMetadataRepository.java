package healthcheck.api.healthcheck.repository;

import healthcheck.api.healthcheck.entity.FileMetadata;
import org.springframework.data.jpa.repository.JpaRepository;


public interface FileMetadataRepository extends JpaRepository<FileMetadata, Long> {
}