package com.example.healthcheck.Controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.http.ResponseEntity;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;

@RestController
public class HealthController {

    @GetMapping("/health")
    public String health() {
        return "OK";
    }

    @PostMapping("/upload")
    public ResponseEntity<String> uploadFile(@RequestParam("file") MultipartFile file) {
        try {
            // Create the upload directory if it does not already exist
            Path uploadDir = Paths.get("uploaded_files");
            Files.createDirectories(uploadDir);

            // Create the full path using the uploaded file's original name
            Path filePath = uploadDir.resolve(file.getOriginalFilename());

            // Save the uploaded file to the upload directory
            // Replace the existing file if a file with the same name already exists
            Files.copy(file.getInputStream(), filePath, StandardCopyOption.REPLACE_EXISTING);

            // Return a success response with the uploaded file name
            return ResponseEntity.ok("File uploaded successfully: " + file.getOriginalFilename());

        }
        catch (IOException e) {
            // Return an error response if the file cannot be saved
            return ResponseEntity.internalServerError().body("Failed to upload file");
        }
    }
}