# File Upload Testing (Docker)

Test file upload support in the containerized Spring Boot application.

## Setup & Run

1. Create the upload folder on Windows:
```bash
mkdir shared_upload_files
```

2. Build the Docker image:
```bash
docker build -t healthcheck-app .
```

3. Stop and remove the previous container if needed:
```bash
docker compose down
```

4. Start the application with Docker Compose:
```bash
docker compose up --build -d
```

5. Check the running container:
```bash
docker ps
```

## Test File Upload

1. Open **Postman** and create a new request:
   - Method: `POST`
   - URL: `http://localhost:8000/upload`
   - Body → Select **form-data**
   - Add key: `file` and set type to **File**
   - Select a file and click **Send**

2. Check the uploaded file on Windows:
```
shared_upload_files/
```

3. Check the uploaded file inside the Docker container:
```bash
docker exec -it healthcheck-container sh
cd /app/uploaded_files
ls
```

4. One-line verification:
```bash
docker exec healthcheck-container ls -la /app/uploaded_files
```

## How It Works

The Docker bind mount defined in `docker-compose.yml`:

```yaml
volumes:
  - ./shared_upload_files:/app/uploaded_files
```

This maps the Windows folder `./shared_upload_files` to `/app/uploaded_files` inside the container. Any file uploaded through the application is stored in `/app/uploaded_files` inside the container and is automatically available in `shared_upload_files` on Windows.

## Spring Boot API + Oracle Free DB Docker Compose Task

### Task Overview

The Spring Boot API stores uploaded files in the upload directory. File metadata is stored in Oracle Free DB. Both the API and Oracle DB run as Docker containers using Docker Compose. The API communicates with Oracle through Docker's internal network.

### Database

- Docker image: `gvenzl/oracle-free:23-slim`
- Oracle service: `FREEPDB1`
- The database port is not exposed in the final configuration.
- The API connects to Oracle using the Docker service name `oracle-db`, not `localhost`.

### File Metadata

The `FILE_METADATA` table stores:

- File name
- File type
- File size
- File path
- Upload date/time

### Environment Variables

Database credentials are stored in a `.env` file. The `.env` file is excluded from Git using `.gitignore`. Do not commit real passwords or secrets.

### Build and Run

```bash
docker compose build
docker compose up -d
```

Or:

```bash
docker compose up -d --build
```

### Check Containers

```bash
docker compose ps
```

Oracle should become `healthy` before the API starts.

### Check Logs

```bash
docker compose logs oracle-db
docker compose logs api
docker compose logs -f
```

### Test File Upload

Test the existing `/upload` endpoint by sending a `POST` request with form-data key `file`. A successful upload should save the actual file in the upload directory and insert its metadata into Oracle DB.

### Check Database from the Oracle Container

```bash
docker exec -it oracle-free-db sqlplus <username>/<password>@FREEPDB1
```

Then run:

```sql
SELECT * FROM FILE_METADATA;
```

Use placeholder credentials in documentation and examples instead of real passwords.

### Temporary DB Visualizer Testing

During development only, port `1521` can temporarily be exposed for DB visualizer testing:

```yaml
ports:
  - "1521:1521"
```

Remove this after testing because Oracle DB should only be accessible internally in the final configuration.

### Stop Containers

```bash
docker compose down
```
