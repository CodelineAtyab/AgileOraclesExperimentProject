package com.example.healthcheck.Controller;

import com.example.healthcheck.model.FileMetadata;
import com.example.healthcheck.repository.FileMetadataRepository;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.time.LocalDateTime;

@RestController
public class HealthController {

    private final FileMetadataRepository fileMetadataRepository;

    public HealthController(FileMetadataRepository fileMetadataRepository) {
        this.fileMetadataRepository = fileMetadataRepository;
    }

    @GetMapping("/health")
    public String health() {
        return "OK";
    }

    @PostMapping("/upload")
    public ResponseEntity<String> uploadFile(
            @RequestParam("file") MultipartFile file) {

        try {
            // Create the upload directory if it does not already exist
            Path uploadDir = Paths.get("uploaded_files");
            Files.createDirectories(uploadDir);

            // Create the full path using the uploaded file's original name
            Path filePath = uploadDir.resolve(file.getOriginalFilename());

            // Save the uploaded file to the upload directory
            Files.copy(
                    file.getInputStream(),
                    filePath,
                    StandardCopyOption.REPLACE_EXISTING
            );

            // Create metadata for the uploaded file
            FileMetadata metadata = new FileMetadata(
                    file.getOriginalFilename(),
                    file.getContentType(),
                    file.getSize(),
                    filePath.toString(),
                    LocalDateTime.now()
            );

            // Save the file metadata to Oracle Database
            fileMetadataRepository.save(metadata);

            // Return a success response
            return ResponseEntity.ok(
                    "File uploaded successfully: "
                            + file.getOriginalFilename()
            );

        } catch (IOException e) {

            return ResponseEntity
                    .internalServerError()
                    .body("Failed to upload file");
        }
    }
}