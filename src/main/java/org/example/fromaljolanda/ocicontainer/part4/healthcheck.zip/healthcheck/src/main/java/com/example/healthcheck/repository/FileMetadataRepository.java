package com.example.healthcheck.repository;

import com.example.healthcheck.model.FileMetadata;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FileMetadataRepository
        extends JpaRepository<FileMetadata, Long> {
}