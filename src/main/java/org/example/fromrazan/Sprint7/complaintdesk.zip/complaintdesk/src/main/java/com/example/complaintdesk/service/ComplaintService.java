package com.example.complaintdesk.service;

import com.example.complaintdesk.model.Complaint;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicLong;


@Service
public class ComplaintService {

    private Map<Long, Complaint> complaints =
            new HashMap<>();

    private AtomicLong counter =
            new AtomicLong();

    //creat Complaint


    public Complaint createComplaint(
            Complaint complaint){

        Long id = counter.incrementAndGet();

        complaint.setId(id);


       complaint.setCreateAt(
               LocalDateTime.now().toString()
       );

       complaints.put(id, complaint);
        return complaint;
    }
      //Get All Complaints

    public List<Complaint> getAllComplaints() {

        return new ArrayList<>(
                complaints.values()
        );
    }

        //get complaint By ID

        public Complaint getComplaintById(Long id){

        return complaints.get(id);
    }


    //delete Complaint
    public boolean deleteComplaint(Long id){
        return complaints.remove(id) !=null;
    }
}
