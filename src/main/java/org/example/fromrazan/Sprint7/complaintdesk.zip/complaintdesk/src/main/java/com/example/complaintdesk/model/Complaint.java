package com.example.complaintdesk.model;

public class Complaint {

    private Long id;
    private String title;
    private String description;
    private String submittedBy;
    private String createAt;


    //Empty constructor
    public Complaint() {

    }


    //full constructor

    public Complaint(Long id, String title, String description, String submittedBy, String createAt) {

        this.id = id;
        this.title = title;
        this.description = description;
        this.submittedBy = submittedBy;
        this.createAt = createAt;


    }

    //Getters and Setters

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getSubmittedBy(String submittedBy) {
        return submittedBy;
    }

    public void setSubmittedBy(String submittedBy) {
        this.submittedBy = submittedBy;

    }


   public String getCreateAt(){
        return createAt;
   }

   public void setCreateAt(String createAt){
        this.createAt = createAt;
   }

}
