package com.example.complaintdesk.controller;

import com.example.complaintdesk.model.Complaint;
import com.example.complaintdesk.service.ComplaintService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;


@RestController
@RequestMapping("/complaints")


public class ComplaintController {

    private final ComplaintService complaintService;

    //constructor Injection
    public ComplaintController(
            ComplaintService complaintService){

        this.complaintService = complaintService;
    }

  //post
   @PostMapping
   public ResponseEntity<Complaint> createComplaint(
           @RequestBody Complaint complaint){

        Complaint savedComplaint = complaintService.createComplaint(complaint);
        return ResponseEntity.status(201).body(savedComplaint);
   }

   //get all

    @GetMapping
    public ResponseEntity<?> getAllComplaints() {

        return ResponseEntity.ok(
                complaintService.getAllComplaints()
        );
    }

        //Get By ID

        @GetMapping("/{id}")
                public ResponseEntity<?> getComplaintById(
                        @PathVariable Long id) {

            Complaint complaint = complaintService.getComplaintById(id);

            if (complaint== null){

                return ResponseEntity.status(404).body("complaint not found");

            }

            return ResponseEntity.ok(complaint);

        }

        //delete
        @DeleteMapping("/{id}")
                public ResponseEntity<?> deleteComplaint(
                        @PathVariable Long id ){

            boolean deleted = complaintService.deleteComplaint(id);

            if (!deleted){

                return ResponseEntity.status(404).body("complaint not found");
            }

            Map<String, String> response = new HashMap<>();

            response.put("message",
                    "compliant with id" + id +
                             "has been deleted successfully."
            );

            return ResponseEntity.ok(response);

        }
    }



