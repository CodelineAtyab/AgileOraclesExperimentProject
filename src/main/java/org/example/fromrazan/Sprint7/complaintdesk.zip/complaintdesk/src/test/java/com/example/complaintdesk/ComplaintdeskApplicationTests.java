package com.example.complaintdesk;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ComplaintdeskApplicationTests {

	@Test
	void contextLoads() {
	}

}
