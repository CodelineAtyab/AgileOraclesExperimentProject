package com.codelineatyab.securepassapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SecurepassappApplication {

    public static void main(String[] args) {
        SpringApplication.run(SecurepassappApplication.class, args);
    }

}
