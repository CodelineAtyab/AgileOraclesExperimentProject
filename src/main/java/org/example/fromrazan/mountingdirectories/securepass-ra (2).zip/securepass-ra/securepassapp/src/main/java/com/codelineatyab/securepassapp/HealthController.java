package com.codelineatyab.securepassapp;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
public class HealthController {

    @GetMapping("/health")
    public Map<String, String> health() {
        // Returning a 2xx body from a @RestController method automatically
        // sends HTTP 200 OK - no need to set status explicitly.
        return Map.of("status", "UP");
    }

}
