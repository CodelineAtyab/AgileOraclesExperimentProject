package om.litedesk.litedesk_api.controllers;


import om.litedesk.litedesk_api.models.Feedback;
import om.litedesk.litedesk_api.services.FeedbackTicketService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@RestController
@RequestMapping(path = "/feedbacks")
public class FeedbackTicketController {

    @Autowired
    public FeedbackTicketService feedbackTicketService;

    @GetMapping
    public ResponseEntity<List<Feedback>> getAll() {
        return ResponseEntity.status(HttpStatus.ACCEPTED).body(feedbackTicketService.getAllFeedbacks());
    }

    @GetMapping(path = "/{id}")
    public ResponseEntity<Feedback> getSpecificFeedback(@PathVariable String id) {
        return ResponseEntity.status(HttpStatus.ACCEPTED).body(feedbackTicketService.getFeedback(id));
    }

    @PostMapping
    public Feedback storeIncomingFeedback(@RequestBody Feedback incomingFeedback) {
        return feedbackTicketService.createFeedback(incomingFeedback);
    }
}
