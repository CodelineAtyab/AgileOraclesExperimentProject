package om.litedesk.litedesk_api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LitedeskApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(LitedeskApiApplication.class, args);
	}

}
