package om.litedesk.litedesk_api.services;

import om.litedesk.litedesk_api.models.Feedback;
import om.litedesk.litedesk_api.repositories.FeedbackRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;

@Service
public class FeedbackTicketService {

    @Autowired
    private FeedbackRepository feedbackRepository;

    public List<Feedback> getAllFeedbacks() {
        return feedbackRepository.findAll();
    }

    public Feedback getFeedback(String id) {
        return feedbackRepository.findById(id).orElse(null);
    }

    public Feedback createFeedback(Feedback givenFeedback) {
        givenFeedback.id = UUID.randomUUID().toString();
        return feedbackRepository.save(givenFeedback);
    }

    public void removeFeedback(String id) {
        feedbackRepository.deleteById(id);
    }
}

