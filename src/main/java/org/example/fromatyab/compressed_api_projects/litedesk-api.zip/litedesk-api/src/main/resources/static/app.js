/* ============================================================
   app.js — Quote fetcher + Particle engine
   ============================================================ */

'use strict';

/* ---------- Quote Fetcher ---------- */
const quoteContent   = document.getElementById('quote-content');
const quoteText      = document.getElementById('quote-text');
const attribution    = document.querySelector('.quote-attribution');
const statusDot      = document.getElementById('status-dot');
const statusText     = document.getElementById('status-text');

async function fetchAndDisplayQuote() {
  try {
    const response = await fetch('/quotes');
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const quote = await response.text();

    // animate out
    quoteText.classList.add('leaving');
    attribution.classList.add('hidden');

    await wait(700);

    quoteContent.textContent = quote;

    // animate in
    quoteText.classList.remove('leaving');
    quoteText.classList.add('entering');

    // force reflow so transition fires
    void quoteText.offsetWidth;

    quoteText.classList.remove('entering');
    attribution.classList.remove('hidden');

    setStatus('success', 'Next prophecy in 5 seconds…');
  } catch (err) {
    setStatus('error', 'The magic failed — retrying soon…');
    console.error('[Wizard Codex] fetch error:', err);
  }
}

function setStatus(type, message) {
  statusDot.className = 'status-dot ' + type;
  statusText.textContent = message;
}

function wait(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

// initial load + repeat every 5 s
fetchAndDisplayQuote();
setInterval(fetchAndDisplayQuote, 5000);


/* ---------- Particle Engine ---------- */
const canvas = document.getElementById('particles-canvas');
const ctx    = canvas.getContext('2d');

const PARTICLE_COUNT = 90;
const particles = [];

class Particle {
  constructor() {
    this.reset(true);
  }

  reset(initial = false) {
    this.x    = Math.random() * canvas.width;
    this.y    = initial ? Math.random() * canvas.height : canvas.height + 10;
    this.size = Math.random() * 2.2 + 0.4;
    this.speedY = -(Math.random() * 0.55 + 0.15);
    this.speedX = (Math.random() - 0.5) * 0.3;
    this.opacity = Math.random() * 0.7 + 0.2;
    this.twinkleSpeed = Math.random() * 0.02 + 0.005;
    this.twinkleOffset = Math.random() * Math.PI * 2;

    // gold or purple sparks
    this.color = Math.random() < 0.55
      ? `rgba(240, 192, 64,`    // gold
      : `rgba(176, 126, 248,`;  // purple
  }

  update(t) {
    this.y += this.speedY;
    this.x += this.speedX;
    const alpha = this.opacity * (0.5 + 0.5 * Math.sin(t * this.twinkleSpeed + this.twinkleOffset));

    ctx.beginPath();
    ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2);
    ctx.fillStyle = `${this.color} ${alpha})`;
    ctx.fill();

    if (this.y < -10) this.reset();
  }
}

function resizeCanvas() {
  canvas.width  = window.innerWidth;
  canvas.height = window.innerHeight;
}

function initParticles() {
  particles.length = 0;
  for (let i = 0; i < PARTICLE_COUNT; i++) {
    particles.push(new Particle());
  }
}

let frameCount = 0;
function animate() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  frameCount++;
  for (const p of particles) p.update(frameCount);
  requestAnimationFrame(animate);
}

window.addEventListener('resize', () => {
  resizeCanvas();
  initParticles();
});

resizeCanvas();
initParticles();
animate();
