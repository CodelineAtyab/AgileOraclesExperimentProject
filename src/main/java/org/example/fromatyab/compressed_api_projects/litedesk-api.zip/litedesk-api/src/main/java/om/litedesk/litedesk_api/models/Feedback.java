package om.litedesk.litedesk_api.models;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "FEEDBACK")
public class Feedback {

    @Id
    @Column(name = "ID", length = 36)
    public String id;

    @Column(name = "CONTENT")
    public String content;
}
