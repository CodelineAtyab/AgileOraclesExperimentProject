package om.litedesk.litedesk_api.repositories;

import om.litedesk.litedesk_api.models.Feedback;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface FeedbackRepository extends JpaRepository<Feedback, String> {
    // JpaRepository provides: findAll, findById, save, deleteById — nothing extra needed
}
