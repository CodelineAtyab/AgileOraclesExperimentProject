package om.litedesk.litedesk_api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LitedeskApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
