package com.example.demo;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.time.LocalDateTime;
import java.util.*;
import java.util.concurrent.atomic.AtomicLong;

@RestController
@RequestMapping("/complaints")
public class ComplaintController {


    private Map<Long, Complaint> complaints = new HashMap<>();


    private AtomicLong counter = new AtomicLong(1);

    // POST
    @PostMapping
    public ResponseEntity<Complaint> addComplaint(@RequestBody Complaint complaint) {
        complaint.setId(counter.getAndIncrement());
        complaint.setCreatedAt(LocalDateTime.now().toString());
        complaints.put(complaint.getId(), complaint);
        return ResponseEntity.status(201).body(complaint);
    }

    // GET
    @GetMapping
    public ResponseEntity<Collection<Complaint>> getAllComplaints() {
        return ResponseEntity.ok(complaints.values());
    }

    //  GET /{id}
    @GetMapping("/{id}")
    public ResponseEntity<?> getComplaint(@PathVariable Long id) {
        Complaint complaint = complaints.get(id);
        if (complaint == null) {
            return ResponseEntity.status(404).body("Complaint not found");
        }
        return ResponseEntity.ok(complaint);
    }

    // DELETE /{id}
    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteComplaint(@PathVariable Long id) {
        if (!complaints.containsKey(id)) {
            return ResponseEntity.status(404).body("Complaint not found");
        }
        complaints.remove(id);
        return ResponseEntity.ok(Map.of("message", "Complaint with id " + id + " has been deleted successfully."));
    }
}
