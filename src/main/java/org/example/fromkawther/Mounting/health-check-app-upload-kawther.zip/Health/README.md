# health-check-app

Spring Boot app with:
- GET /health → returns 200 OK
- POST /upload → uploads a file, saved to /app/uploaded_files (bind-mounted to ./shared_upload_files on the host)

## Run
docker compose up --build

## Test
curl http://localhost:8080/health
# Upload via Postman: POST http://localhost:8080/upload, Body → form-data → key "file" (type File)