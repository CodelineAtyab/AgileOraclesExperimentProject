package com.example.healthcheckapp;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "FILE_METADATA")
public class FileMetadata {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String filename;
    private LocalDateTime uploadedAt;

    public FileMetadata() {}

    public FileMetadata(String filename, LocalDateTime uploadedAt) {
        this.filename = filename;
        this.uploadedAt = uploadedAt;
    }

    public Long getId() { return id; }
    public String getFilename() { return filename; }
    public LocalDateTime getUploadedAt() { return uploadedAt; }
}
