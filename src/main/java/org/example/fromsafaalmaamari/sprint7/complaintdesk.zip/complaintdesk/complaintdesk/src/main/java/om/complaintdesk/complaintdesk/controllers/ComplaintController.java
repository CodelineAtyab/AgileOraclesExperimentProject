package om.complaintdesk.complaintdesk.controllers;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping(path = "/complaints")
    public class ComplaintController {
    

    }


