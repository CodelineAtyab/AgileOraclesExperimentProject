package om.complaintdesk.complaintdesk.models;

public class Complaint {

    public Long id;

    public String title;

    public  String description;

    public String submittedBy;

    public String createdAt;
}
