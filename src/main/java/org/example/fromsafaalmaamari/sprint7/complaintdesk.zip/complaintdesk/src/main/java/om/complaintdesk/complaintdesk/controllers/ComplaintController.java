package om.complaintdesk.complaintdesk.controllers;
import om.complaintdesk.complaintdesk.models.Complaint;
import org.springframework.web.bind.annotation.*;
import java.time.LocalDateTime;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicLong;


@RestController
@RequestMapping(path = "/complaints")
    public class ComplaintController {

    private List<Complaint> complaintStore = new CopyOnWriteArrayList<>();

    private AtomicLong idCounter = new AtomicLong(1);

    @PostMapping
    public Complaint storeIncomingComplaint (@RequestBody Complaint incomingComplaint){
        incomingComplaint.id = idCounter.getAndIncrement();
        incomingComplaint.createdAt = LocalDateTime.now().toString();

        complaintStore.add(incomingComplaint);
        return incomingComplaint;
    }

    @GetMapping
    public List<Complaint> getAllComplaints(){
        return complaintStore;
    }
    @GetMapping(path = "/{id}")
    public Complaint getSpecificComplaint (@PathVariable Long id){
        for (Complaint currComplaintObj : complaintStore){
            if (currComplaintObj.id.equals(id)){
                return currComplaintObj;
            }
        }
        return null;
    }

    @DeleteMapping(path = "/{id}")
    public String deleteSpecificComplaint (@PathVariable Long id){
        for (Complaint currComplaint : complaintStore){
            if (id.equals(currComplaint.id)){
                complaintStore.remove(currComplaint);
                return "Complaint with id " + id + " has been deleted successfully.";
            }
        }
        return "Complaint not found";
    }
    }