package com.example.healthcheck_task;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HealthcheckTaskApplication {

	public static void main(String[] args) {
		SpringApplication.run(HealthcheckTaskApplication.class, args);
	}

}
