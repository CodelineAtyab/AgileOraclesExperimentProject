package com.example.healthcheck_task;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HealthcheckTaskApplicationTests {

	@Test
	void contextLoads() {
	}

}
