package com.example.deployment;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

import java.time.Instant;

@Entity
@Table(name = "UPLOAD_META")
public class UploadMeta {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(name = "FILENAME", nullable = false, length = 255)
	private String filename;

	@Column(name = "FILE_SIZE")
	private Long fileSize;

	@Column(name = "STORED_PATH", length = 500)
	private String storedPath;

	@Column(name = "UPLOADED_AT")
	private Instant uploadedAt = Instant.now();

	public Long getId() { return id; }
	public String getFilename() { return filename; }
	public void setFilename(String filename) { this.filename = filename; }
	public Long getFileSize() { return fileSize; }
	public void setFileSize(Long fileSize) { this.fileSize = fileSize; }
	public String getStoredPath() { return storedPath; }
	public void setStoredPath(String storedPath) { this.storedPath = storedPath; }
	public Instant getUploadedAt() { return uploadedAt; }
	public void setUploadedAt(Instant uploadedAt) { this.uploadedAt = uploadedAt; }
}
