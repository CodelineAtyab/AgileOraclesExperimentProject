package com.example.deployment;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.server.ResponseStatusException;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.Instant;
import java.util.LinkedHashMap;
import java.util.Map;

@RestController
public class FileUploadController {

	private final Path uploadDir;
	private final UploadMetaRepository repository;

	public FileUploadController(
			@Value("${app.upload-dir:uploaded_files}") String uploadDir,
			UploadMetaRepository repository) {
		this.uploadDir = Paths.get(uploadDir).toAbsolutePath().normalize();
		this.repository = repository;
	}

	@PostMapping("/upload")
	public Map<String, Object> upload(@RequestParam("file") MultipartFile file) throws IOException {
		if (file == null || file.isEmpty()) {
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "file is required");
		}

		String original = file.getOriginalFilename();
		if (original == null || original.isBlank()) {
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "filename is required");
		}

		String safeName = Paths.get(original).getFileName().toString();
		Files.createDirectories(uploadDir);
		Path destination = uploadDir.resolve(safeName);
		file.transferTo(destination);

		UploadMeta meta = new UploadMeta();
		meta.setFilename(safeName);
		meta.setFileSize(file.getSize());
		meta.setStoredPath(destination.toString());
		meta.setUploadedAt(Instant.now());
		meta = repository.save(meta);

		Map<String, Object> body = new LinkedHashMap<>();
		body.put("message", "uploaded");
		body.put("id", meta.getId());
		body.put("filename", safeName);
		body.put("fileSize", meta.getFileSize());
		body.put("savedTo", destination.toString());
		body.put("uploadedAt", meta.getUploadedAt().toString());
		return body;
	}
}
