package com.example.deployment;

import org.springframework.data.jpa.repository.JpaRepository;

public interface UploadMetaRepository extends JpaRepository<UploadMeta, Long> {
}
