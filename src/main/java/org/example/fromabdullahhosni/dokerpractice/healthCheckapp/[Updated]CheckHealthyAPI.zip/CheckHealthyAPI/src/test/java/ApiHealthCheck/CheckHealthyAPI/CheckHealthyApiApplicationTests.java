package ApiHealthCheck.CheckHealthyAPI;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CheckHealthyApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
