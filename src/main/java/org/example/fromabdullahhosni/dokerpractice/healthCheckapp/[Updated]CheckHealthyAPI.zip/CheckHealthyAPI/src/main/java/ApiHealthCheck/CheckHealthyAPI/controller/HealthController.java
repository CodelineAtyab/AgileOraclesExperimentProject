package ApiHealthCheck.CheckHealthyAPI.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
public class HealthController {

    private static final String STATUS_MESSAGE =
            "Hello, space explorer! I'm your CheckHealthy application, cruising the cosmos like a "
                    + "spaceship — fuel your dreams, launch past every star, and blast through the "
                    + "galaxy toward the orbit of greatness awaiting you!";

    private static final String QUOTE =
            "Across every wormhole and galaxy, love and gravity still guide us home. 🚀";

    @GetMapping("/health")
    public ResponseEntity<Map<String, String>> health() {
        return ResponseEntity.ok(Map.of(
                "status", STATUS_MESSAGE,
                "quote", QUOTE));
    }
}
