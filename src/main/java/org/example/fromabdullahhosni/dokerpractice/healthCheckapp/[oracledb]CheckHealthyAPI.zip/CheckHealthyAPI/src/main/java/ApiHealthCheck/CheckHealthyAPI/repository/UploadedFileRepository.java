package ApiHealthCheck.CheckHealthyAPI.repository;

import ApiHealthCheck.CheckHealthyAPI.model.UploadedFile;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UploadedFileRepository extends JpaRepository<UploadedFile, Long> {}
