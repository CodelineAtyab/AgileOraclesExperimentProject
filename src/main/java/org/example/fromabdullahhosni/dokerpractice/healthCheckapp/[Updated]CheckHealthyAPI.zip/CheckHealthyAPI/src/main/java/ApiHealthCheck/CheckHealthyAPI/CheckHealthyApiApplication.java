package ApiHealthCheck.CheckHealthyAPI;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CheckHealthyApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(CheckHealthyApiApplication.class, args);
	}

}
