package ApiHealthCheck.CheckHealthyAPI.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "files_metadata")
public class UploadedFile {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "uploaded_files_seq")
    @SequenceGenerator(name = "uploaded_files_seq", sequenceName = "uploaded_files_seq", allocationSize = 1)
    private Long id;

    @Column(nullable = false) private String filename;
    @Column(nullable = false) private Long fileSize;
    @Column(nullable = false) private String contentType;
    @Column(nullable = false) private LocalDateTime uploadedAt;

    public UploadedFile() {}

    public Long getId()                        { return id; }
    public String getFilename()                { return filename; }
    public void setFilename(String filename)   { this.filename = filename; }
    public Long getFileSize()                  { return fileSize; }
    public void setFileSize(Long fileSize)     { this.fileSize = fileSize; }
    public String getContentType()             { return contentType; }
    public void setContentType(String ct)      { this.contentType = ct; }
    public LocalDateTime getUploadedAt()       { return uploadedAt; }
    public void setUploadedAt(LocalDateTime t) { this.uploadedAt = t; }
}
