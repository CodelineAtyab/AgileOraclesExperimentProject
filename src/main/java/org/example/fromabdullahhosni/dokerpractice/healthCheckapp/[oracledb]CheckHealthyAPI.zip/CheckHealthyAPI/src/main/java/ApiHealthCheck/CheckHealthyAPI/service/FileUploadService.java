package ApiHealthCheck.CheckHealthyAPI.service;

import ApiHealthCheck.CheckHealthyAPI.model.UploadedFile;
import ApiHealthCheck.CheckHealthyAPI.repository.UploadedFileRepository;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;

@Service
public class FileUploadService {

    @Value("${file.upload.dir}")
    private String uploadDir;

    private final UploadedFileRepository repository;

    public FileUploadService(UploadedFileRepository repository) {
        this.repository = repository;
    }

    public String save(MultipartFile file) throws IOException {
        Path dir = Paths.get(uploadDir);
        Files.createDirectories(dir);

        Path destination = dir.resolve(file.getOriginalFilename());
        file.transferTo(destination);

        UploadedFile record = new UploadedFile();
        record.setFilename(file.getOriginalFilename());
        record.setFileSize(file.getSize());
        record.setContentType(file.getContentType());
        record.setUploadedAt(LocalDateTime.now());
        repository.save(record);

        return file.getOriginalFilename();
    }
}
