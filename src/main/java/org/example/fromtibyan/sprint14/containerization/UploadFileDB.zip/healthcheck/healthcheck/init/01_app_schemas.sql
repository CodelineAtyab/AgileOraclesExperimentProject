-- =====================================================================
-- Creates two isolated application schemas in FREEPDB1.
--
-- Runs as SYS against the CDB root (FREE) when placed in
-- /container-entrypoint-initdb.d, which is why the first thing it does
-- is switch into the pluggable database.
--
-- To run it by hand instead:
--   docker exec -i oracle-free sqlplus -S / as sysdba < init/01_app_schemas.sql
-- =====================================================================

SET ECHO ON
SET SERVEROUTPUT ON
WHENEVER SQLERROR EXIT SQL.SQLCODE

-- Enable Oracle Managed Files so CREATE TABLESPACE needs no datafile paths.
ALTER SYSTEM SET DB_CREATE_FILE_DEST = '/opt/oracle/oradata/FREE' SCOPE = BOTH;

ALTER SESSION SET CONTAINER = FREEPDB1;


-- ---------------------------------------------------------------------
-- APP1
-- ---------------------------------------------------------------------
CREATE TABLESPACE app1_data
  DATAFILE SIZE 100M AUTOEXTEND ON NEXT 50M MAXSIZE 2G;

CREATE USER app1 IDENTIFIED BY "firstpeerpass"
  DEFAULT TABLESPACE app1_data
  QUOTA UNLIMITED ON app1_data;

GRANT DB_DEVELOPER_ROLE TO app1;


-- ---------------------------------------------------------------------
-- APP2
-- ---------------------------------------------------------------------
CREATE TABLESPACE app2_data
  DATAFILE SIZE 100M AUTOEXTEND ON NEXT 50M MAXSIZE 2G;

CREATE USER app2 IDENTIFIED BY "secondpeerpass"
  DEFAULT TABLESPACE app2_data
  QUOTA UNLIMITED ON app2_data;

GRANT DB_DEVELOPER_ROLE TO app2;


-- ---------------------------------------------------------------------
-- Verification
-- ---------------------------------------------------------------------
SELECT username, default_tablespace
  FROM dba_users
 WHERE username IN ('APP1', 'APP2')
 ORDER BY username;

EXIT
