package com.example.healthcheck.repositories;

import com.example.healthcheck.model.Filedata;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface FileRepo extends JpaRepository<Filedata, Long> {
}