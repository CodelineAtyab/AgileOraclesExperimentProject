package com.example.healthcheck.controller;
import java.io.File;
import java.io.IOException;
import java.util.Map;

import org.apache.commons.io.FileUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

@RestController
@RequestMapping("/api/files")
public class FileUploadController {

    @Value("${file.upload-dir:./uploaded-files}")
    private String uploadDir;

    @PostMapping("/upload")
    public ResponseEntity<Map<String, String>> uploadFile(@RequestParam("file") MultipartFile file, @RequestParam("name") String name) throws IOException {
        File dir = new File(uploadDir);
        FileUtils.forceMkdir(dir);

        File dest = new File(dir, name);
        FileUtils.copyInputStreamToFile(file.getInputStream(), dest);

        return ResponseEntity.ok(Map.of("status", "success", "path", dest.getAbsolutePath()));
    }
}