package com.example.ComplaintManagement.models;

import java.time.LocalDateTime;
import java.util.concurrent.atomic.AtomicLong;

public class Complaint {

    private static final AtomicLong counter = new AtomicLong();
    private final long id = counter.incrementAndGet();
    private String title;
    private String description;
    private String submittedBy;
    private String createdAt;

    public Complaint(String title, String description, String submittedBy) {
        this.title = title;
        this.description = description;
        this.submittedBy = submittedBy;
    }

    public long getId() {return id;}

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public String getSubmittedBy() { return submittedBy; }
    public void setSubmittedBy(String submittedBy) { this.submittedBy = submittedBy; }

    public String getCreatedAt() { return LocalDateTime.now().toString(); }

}