package com.example.ComplaintManagement.controllers;

import com.example.ComplaintManagement.models.Complaint;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

@RestController
@RequestMapping("/complaints")
public class ComplaintController {
    private final List<Complaint> complaints = new CopyOnWriteArrayList<>();

    @PostMapping
    public ResponseEntity<Complaint> registerComplaint(@RequestBody Complaint complaint) {
        complaints.add(complaint); // adding the object into array
        return ResponseEntity.status(201).body(complaint); //return 200OK status code response
    }

    @GetMapping
    public List<Complaint> listAllComplaints(){
        return complaints; // displaying array
    }

    @GetMapping (path = "/{id}")
    public ResponseEntity<Complaint> getComplaintByID(@PathVariable long id){
        for (Complaint getComplaintID: complaints){
            if(getComplaintID.getId() == id){ // getting Object with same id as provided id
                return ResponseEntity.ok(getComplaintID); // return 200ok response if found
            }
        }
        return ResponseEntity.notFound().build(); // else return 404 not found response
    }

    @DeleteMapping (path = "/{id}")
    public ResponseEntity<Complaint> deleteComplaintByID(@PathVariable long id){
        for (Complaint getComplaintID: complaints){
            if(getComplaintID.getId() == id){
                complaints.remove(getComplaintID); // deleting the object with that id
                return ResponseEntity.ok(getComplaintID);
            }
        }
        return ResponseEntity.notFound().build();
    }
}


// -----------JSON FORMAT---------------
// {
//         "title": "AC broken",
//         "description": "it is leaking",
//         "submittedBy": "Tibyan"
// }
