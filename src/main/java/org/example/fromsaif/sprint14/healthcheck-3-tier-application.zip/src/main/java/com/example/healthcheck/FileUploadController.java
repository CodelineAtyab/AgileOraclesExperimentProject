package com.example.healthcheck;

import org.springframework.dao.DataAccessException;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.time.LocalDateTime;

@RestController
public class FileUploadController {

    private final Path uploadDirectory =
            Paths.get("uploaded_files").toAbsolutePath().normalize();

    private final FileMetadataRepository fileMetadataRepository;

    public FileUploadController(
            FileMetadataRepository fileMetadataRepository
    ) {
        this.fileMetadataRepository = fileMetadataRepository;
    }

    @PostMapping("/upload")
    public ResponseEntity<String> uploadFile(
            @RequestParam("file") MultipartFile file
    ) {
        if (file.isEmpty()) {
            return ResponseEntity.badRequest()
                    .body("Please select a file");
        }

        String originalFilename = file.getOriginalFilename();

        if (originalFilename == null || originalFilename.isBlank()) {
            return ResponseEntity.badRequest()
                    .body("Invalid filename");
        }

        String safeFilename = Paths.get(originalFilename)
                .getFileName()
                .toString();

        try {
            Files.createDirectories(uploadDirectory);

            Path destination = uploadDirectory.resolve(safeFilename);

            Files.copy(
                    file.getInputStream(),
                    destination,
                    StandardCopyOption.REPLACE_EXISTING
            );

            FileMetadata metadata = new FileMetadata(
                    safeFilename,
                    file.getContentType(),
                    file.getSize(),
                    LocalDateTime.now()
            );

            fileMetadataRepository.save(metadata);

            return ResponseEntity.ok(
                    "File and metadata saved successfully: " + safeFilename
            );
        } catch (IOException | DataAccessException exception) {
            return ResponseEntity.internalServerError()
                    .body("Failed to upload file or save metadata");
        }
    }
}
