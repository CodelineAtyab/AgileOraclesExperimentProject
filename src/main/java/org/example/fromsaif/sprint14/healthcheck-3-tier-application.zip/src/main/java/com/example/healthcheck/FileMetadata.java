package com.example.healthcheck;

import jakarta.persistence.*;

import java.time.LocalDateTime;

@Entity
@Table(name = "FILE_METADATA")
public class FileMetadata {

    @Id
    @GeneratedValue(
            strategy = GenerationType.SEQUENCE,
            generator = "file_metadata_generator"
    )
    @SequenceGenerator(
            name = "file_metadata_generator",
            sequenceName = "FILE_METADATA_SEQUENCE",
            allocationSize = 1
    )
    private Long id;

    @Column(name = "FILE_NAME", nullable = false)
    private String fileName;

    @Column(name = "CONTENT_TYPE")
    private String contentType;

    @Column(name = "FILE_SIZE", nullable = false)
    private long fileSize;

    @Column(name = "UPLOADED_AT", nullable = false)
    private LocalDateTime uploadedAt;

    protected FileMetadata() {
    }

    public FileMetadata(
            String fileName,
            String contentType,
            long fileSize,
            LocalDateTime uploadedAt
    ) {
        this.fileName = fileName;
        this.contentType = contentType;
        this.fileSize = fileSize;
        this.uploadedAt = uploadedAt;
    }

    public Long getId() {
        return id;
    }

    public String getFileName() {
        return fileName;
    }

    public String getContentType() {
        return contentType;
    }

    public long getFileSize() {
        return fileSize;
    }

    public LocalDateTime getUploadedAt() {
        return uploadedAt;
    }
}
