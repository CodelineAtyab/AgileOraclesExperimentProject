package com.example.healthcheck;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;

@RestController
public class FileUploadController {

    private final Path uploadDirectory =
            Paths.get("uploaded_files").toAbsolutePath().normalize();

    @PostMapping("/upload")
    public ResponseEntity<String> uploadFile(
            @RequestParam("file") MultipartFile file) {

        if (file.isEmpty()) {
            return ResponseEntity.badRequest()
                    .body("Please select a file");
        }

        String originalFilename = file.getOriginalFilename();

        if (originalFilename == null || originalFilename.isBlank()) {
            return ResponseEntity.badRequest()
                    .body("Invalid filename");
        }

        String safeFilename = Paths.get(originalFilename)
                .getFileName()
                .toString();

        try {
            Files.createDirectories(uploadDirectory);

            Path destination = uploadDirectory.resolve(safeFilename);

            Files.copy(
                    file.getInputStream(),
                    destination,
                    StandardCopyOption.REPLACE_EXISTING
            );

            return ResponseEntity.ok(
                    "File uploaded successfully: " + safeFilename
            );
        } catch (IOException exception) {
            return ResponseEntity.internalServerError()
                    .body("Failed to upload file");
        }
    }
}
