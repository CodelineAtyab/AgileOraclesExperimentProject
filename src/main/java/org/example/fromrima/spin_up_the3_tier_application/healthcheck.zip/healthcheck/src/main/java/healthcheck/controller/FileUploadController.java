package healthcheck.controller;

import healthcheck.entity.FileMetadata;
import healthcheck.repository.FileMetadataRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.*;
import java.time.LocalDateTime;

@RestController
@RequestMapping("/files")
public class FileUploadController {

    private static final String UPLOAD_DIR = "uploaded_files";

    private final FileMetadataRepository fileMetadataRepository;

    public FileUploadController(FileMetadataRepository fileMetadataRepository) {
        this.fileMetadataRepository = fileMetadataRepository;
    }

    @PostMapping("/upload")
    public ResponseEntity<String> uploadFile(
            @RequestParam("file") MultipartFile file) {

        try {
            Path uploadPath = Paths.get(UPLOAD_DIR);

            if (!Files.exists(uploadPath)) {
                Files.createDirectories(uploadPath);
            }

            Path filePath = uploadPath.resolve(file.getOriginalFilename());

            // Save the actual file
            Files.copy(
                    file.getInputStream(),
                    filePath,
                    StandardCopyOption.REPLACE_EXISTING
            );

            // Save file metadata to Oracle DB
            FileMetadata metadata = new FileMetadata(
                    file.getOriginalFilename(),
                    file.getContentType(),
                    file.getSize(),
                    LocalDateTime.now()
            );

            fileMetadataRepository.save(metadata);

            return ResponseEntity.ok(
                    "File uploaded successfully: " + file.getOriginalFilename()
            );

        } catch (IOException e) {
            return ResponseEntity.internalServerError()
                    .body("Failed to upload file");
        }
    }
}