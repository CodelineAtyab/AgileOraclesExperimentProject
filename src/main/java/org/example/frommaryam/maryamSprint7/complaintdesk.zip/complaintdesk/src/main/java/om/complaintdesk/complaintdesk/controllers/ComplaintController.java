package om.complaintdesk.complaintdesk.controllers;

import om.complaintdesk.complaintdesk.models.Complaint;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicLong;


//  postman -> http://localhost:8080/complaints

//  how to send a complaint:
//  {
//    "title": "internet not working properly",
//    "description": "very slow and unstable",
//    "submittedBy": "anonymous student"
//  }



@RestController
@RequestMapping("/complaints")
public class ComplaintController {

    List<Complaint> complaints = new ArrayList<>();
    AtomicLong counter = new AtomicLong(1);


    // get all
    @GetMapping
    public List<Complaint> getAllComplaints() {
        return complaints;
    }


    // post
    @PostMapping
    public ResponseEntity<Complaint> addComplaint(@RequestBody Complaint complaint) {

        complaint.setId(counter.getAndIncrement());
        complaint.setCreatedAt(LocalDateTime.now().toString());

        complaints.add(complaint);

        return ResponseEntity.status(201).body(complaint);
    }


    // get by id
    @GetMapping("/{id}")
    public ResponseEntity<Complaint> getComplaintById(@PathVariable Long id) {

        for (Complaint complaint : complaints) {
            if (complaint.getId().equals(id)) {
                return ResponseEntity.ok(complaint);
            }
        }

        return ResponseEntity.notFound().build();
    }


    // delete
    @DeleteMapping("/{id}")
    public ResponseEntity<Map<String, String>> deleteComplaint(@PathVariable Long id) {

        Iterator<Complaint> iterator = complaints.iterator();

        while (iterator.hasNext()) {
            Complaint complaint = iterator.next();

            if (complaint.getId().equals(id)) {
                iterator.remove();

                return ResponseEntity.ok(
                        Map.of("message",
                                "Complaint with id " + id + " has been deleted successfully")
                );
            }
        }

        return ResponseEntity.notFound().build();
    }
}


