package om.complaintdesk.complaintdesk;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ComplaintdeskApplication {

	public static void main(String[] args) {
		SpringApplication.run(ComplaintdeskApplication.class, args);
	}

}
