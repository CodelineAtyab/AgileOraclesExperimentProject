package com.example.healthapp;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.time.LocalDateTime;

@RestController
public class FileUploadController {

    // Name of the folder where uploaded files will be stored
    private static final String UPLOAD_DIR = "uploaded_files";

    @Autowired
    private FileMetadataRepository fileMetadataRepository;

    @PostMapping("/upload")
    public String uploadFile(@RequestParam("file") MultipartFile file) throws IOException {

        // Make sure the folder exists, if not, create it
        File folder = new File(UPLOAD_DIR);
        if (!folder.exists()) {
            folder.mkdirs();
        }

        // Build the full path for the new file (folder + file name)
        String fileName = file.getOriginalFilename();
        File newFile = new File(folder, fileName);

        // Take the content of the uploaded file and write it to the new file
        FileOutputStream outputStream = new FileOutputStream(newFile);
        outputStream.write(file.getBytes());
        outputStream.close();

        // Save the file's metadata to the database
        FileMetadata metadata = new FileMetadata();
        metadata.setFileName(fileName);
        metadata.setFileSize(file.getSize());
        metadata.setUploadedAt(LocalDateTime.now());
        fileMetadataRepository.save(metadata);

        // Return a confirmation message
        return "File uploaded: " + fileName;
    }
}