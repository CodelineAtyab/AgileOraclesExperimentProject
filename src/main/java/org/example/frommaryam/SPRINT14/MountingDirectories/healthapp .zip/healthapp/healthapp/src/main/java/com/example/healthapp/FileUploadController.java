package com.example.healthapp;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

@RestController
public class FileUploadController {

    //name of the folder where uploaded files will be stored
    private static final String UPLOAD_DIR = "uploaded_files";

    @PostMapping("/upload")
    public String uploadFile(@RequestParam("file") MultipartFile file) throws IOException {

        //step 1 make sure the folder exists, if not, create it
        File folder = new File(UPLOAD_DIR);
        if (!folder.exists()) {
            folder.mkdirs();
        }

        //step 2 build the full path for the new file
        String fileName = file.getOriginalFilename();
        File newFile = new File(folder, fileName);

        //step 3 take the content of the uploaded file and write it to the new file
        FileOutputStream outputStream = new FileOutputStream(newFile);
        outputStream.write(file.getBytes());
        outputStream.close();

        //step 4 return a confirmation message
        return "File uploaded: " + fileName;
    }
}