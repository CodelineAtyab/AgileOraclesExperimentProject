package com.example.healthcheck.upload;

import java.io.IOException;
import java.time.LocalDateTime;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import com.example.healthcheck.upload.FileStorageService.StorageResult;

@Service
public class FileUploadService {

	private final FileStorageService fileStorageService;
	private final FileMetadataRepository metadataRepository;

	public FileUploadService(FileStorageService fileStorageService,
			FileMetadataRepository metadataRepository) {
		this.fileStorageService = fileStorageService;
		this.metadataRepository = metadataRepository;
	}

	@Transactional
	public UploadResult upload(MultipartFile file, boolean overwrite) throws IOException {
		StorageResult storedFile = fileStorageService.store(file, overwrite);

		FileMetadata metadata = metadataRepository
				.findByFilename(storedFile.filename())
				.orElseGet(FileMetadata::new);

		metadata.setFilename(storedFile.filename());
		metadata.setContentType(file.getContentType());
		metadata.setSizeBytes(file.getSize());
		metadata.setStoragePath(storedFile.storagePath());
		metadata.setUploadedAt(LocalDateTime.now());
		metadataRepository.save(metadata);

		return new UploadResult(storedFile.filename(), storedFile.overwritten());
	}

	public record UploadResult(String filename, boolean overwritten) {
	}
}
