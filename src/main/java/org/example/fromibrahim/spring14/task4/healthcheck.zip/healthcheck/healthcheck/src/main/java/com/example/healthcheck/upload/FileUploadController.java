package com.example.healthcheck.upload;

import java.io.IOException;
import java.nio.file.FileAlreadyExistsException;

import org.springframework.dao.DataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.example.healthcheck.upload.FileUploadService.UploadResult;

@RestController
public class FileUploadController {

	private final FileUploadService fileUploadService;

	public FileUploadController(FileUploadService fileUploadService) {
		this.fileUploadService = fileUploadService;
	}

	@PostMapping(value = "/upload", consumes = MediaType.MULTIPART_FORM_DATA_VALUE,
			produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<UploadResponse> upload(@RequestParam("file") MultipartFile file,
			@RequestParam(value = "overwrite", defaultValue = "false") boolean overwrite) {
		try {
			UploadResult result = fileUploadService.upload(file, overwrite);
			String message = result.overwritten()
					? "The file was overwritten successfully."
					: "The file was uploaded successfully.";
			return ResponseEntity.ok(new UploadResponse(message, result.filename(), false));
		} catch (FileAlreadyExistsException exception) {
			return ResponseEntity.status(HttpStatus.CONFLICT)
					.body(new UploadResponse(
							"You have already uploaded this file. If you want to overwrite it, confirm Yes by resending with overwrite=true.",
							file.getOriginalFilename(), true));
		} catch (IllegalArgumentException exception) {
			return ResponseEntity.badRequest()
					.body(new UploadResponse(exception.getMessage(), file.getOriginalFilename(), false));
		} catch (DataAccessException exception) {
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
					.body(new UploadResponse(
							"The file was stored, but its metadata could not be saved.",
							file.getOriginalFilename(), false));
		} catch (IOException exception) {
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
					.body(new UploadResponse("The file could not be stored.", file.getOriginalFilename(), false));
		}
	}

	public record UploadResponse(String message, String filename, boolean overwriteRequired) {
	}
}
