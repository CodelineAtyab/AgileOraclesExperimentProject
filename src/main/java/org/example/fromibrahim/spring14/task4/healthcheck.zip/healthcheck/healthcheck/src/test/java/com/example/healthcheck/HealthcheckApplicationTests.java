package com.example.healthcheck;

import static org.hamcrest.Matchers.containsString;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.multipart;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Comparator;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.web.servlet.MockMvc;

import com.example.healthcheck.upload.FileMetadata;
import com.example.healthcheck.upload.FileMetadataRepository;

@SpringBootTest
@AutoConfigureMockMvc
class HealthcheckApplicationTests {
	private static final Path TEST_UPLOAD_DIRECTORY = Path.of("target/test-uploads");

	@Autowired
	private MockMvc mockMvc;

	@Autowired
	private FileMetadataRepository metadataRepository;

	@BeforeEach
	void clearUploadedFiles() throws IOException {
		metadataRepository.deleteAll();

		if (Files.exists(TEST_UPLOAD_DIRECTORY)) {
			try (var paths = Files.walk(TEST_UPLOAD_DIRECTORY)) {
				paths.sorted(Comparator.reverseOrder())
						.forEach(path -> {
							try {
								Files.delete(path);
							} catch (IOException exception) {
								throw new RuntimeException(exception);
							}
						});
			}
		}
	}

	@Test
	void contextLoads() {
	}

	@Test
	void healthReturnsHealthyAsPlainText() throws Exception {
		mockMvc.perform(get("/health"))
				.andExpect(status().isOk())
				.andExpect(content().contentTypeCompatibleWith(MediaType.TEXT_PLAIN))
				.andExpect(content().string("healthy"));
	}

	@Test
	void homeReturnsNotFound() throws Exception {
		mockMvc.perform(get("/"))
				.andExpect(status().isNotFound());
	}

	@Test
	void uploadStoresNewFile() throws Exception {
		MockMultipartFile file = new MockMultipartFile(
				"file", "example.txt", MediaType.TEXT_PLAIN_VALUE, "first version".getBytes());

		mockMvc.perform(multipart("/upload").file(file))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$.message").value("The file was uploaded successfully."))
				.andExpect(jsonPath("$.filename").value("example.txt"))
				.andExpect(jsonPath("$.overwriteRequired").value(false));

		org.junit.jupiter.api.Assertions.assertEquals(
				"first version", Files.readString(TEST_UPLOAD_DIRECTORY.resolve("example.txt")));

		FileMetadata metadata = metadataRepository.findByFilename("example.txt").orElseThrow();
		org.junit.jupiter.api.Assertions.assertEquals("text/plain", metadata.getContentType());
		org.junit.jupiter.api.Assertions.assertEquals(13, metadata.getSizeBytes());
		org.junit.jupiter.api.Assertions.assertTrue(metadata.getStoragePath().endsWith("example.txt"));
		org.junit.jupiter.api.Assertions.assertNotNull(metadata.getUploadedAt());
	}

	@Test
	void duplicateRequiresConfirmationAndPreservesExistingFile() throws Exception {
		MockMultipartFile original = new MockMultipartFile(
				"file", "duplicate.txt", MediaType.TEXT_PLAIN_VALUE, "original".getBytes());
		MockMultipartFile replacement = new MockMultipartFile(
				"file", "duplicate.txt", MediaType.TEXT_PLAIN_VALUE, "replacement".getBytes());
		mockMvc.perform(multipart("/upload").file(original)).andExpect(status().isOk());
		FileMetadata initialMetadata = metadataRepository.findByFilename("duplicate.txt").orElseThrow();
		Long initialId = initialMetadata.getId();
		var initialUploadedAt = initialMetadata.getUploadedAt();

		mockMvc.perform(multipart("/upload").file(replacement))
				.andExpect(status().isConflict())
				.andExpect(jsonPath("$.message", containsString("overwrite=true")))
				.andExpect(jsonPath("$.filename").value("duplicate.txt"))
				.andExpect(jsonPath("$.overwriteRequired").value(true));

		org.junit.jupiter.api.Assertions.assertEquals(
				"original", Files.readString(TEST_UPLOAD_DIRECTORY.resolve("duplicate.txt")));
		org.junit.jupiter.api.Assertions.assertEquals(1, metadataRepository.count());
		FileMetadata preservedMetadata = metadataRepository.findByFilename("duplicate.txt").orElseThrow();
		org.junit.jupiter.api.Assertions.assertEquals(initialId, preservedMetadata.getId());
		org.junit.jupiter.api.Assertions.assertEquals(8, preservedMetadata.getSizeBytes());
		org.junit.jupiter.api.Assertions.assertEquals(initialUploadedAt, preservedMetadata.getUploadedAt());
	}

	@Test
	void overwriteTrueReplacesExistingFile() throws Exception {
		MockMultipartFile original = new MockMultipartFile(
				"file", "duplicate.txt", MediaType.TEXT_PLAIN_VALUE, "original".getBytes());
		MockMultipartFile replacement = new MockMultipartFile(
				"file", "duplicate.txt", MediaType.TEXT_PLAIN_VALUE, "replacement".getBytes());
		mockMvc.perform(multipart("/upload").file(original)).andExpect(status().isOk());
		FileMetadata initialMetadata = metadataRepository.findByFilename("duplicate.txt").orElseThrow();
		Long initialId = initialMetadata.getId();
		var initialUploadedAt = initialMetadata.getUploadedAt();

		mockMvc.perform(multipart("/upload").file(replacement).param("overwrite", "true"))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$.message").value("The file was overwritten successfully."))
				.andExpect(jsonPath("$.overwriteRequired").value(false));

		org.junit.jupiter.api.Assertions.assertEquals(
				"replacement", Files.readString(TEST_UPLOAD_DIRECTORY.resolve("duplicate.txt")));
		org.junit.jupiter.api.Assertions.assertEquals(1, metadataRepository.count());
		FileMetadata updatedMetadata = metadataRepository.findByFilename("duplicate.txt").orElseThrow();
		org.junit.jupiter.api.Assertions.assertEquals(initialId, updatedMetadata.getId());
		org.junit.jupiter.api.Assertions.assertEquals(11, updatedMetadata.getSizeBytes());
		org.junit.jupiter.api.Assertions.assertNotEquals(initialUploadedAt, updatedMetadata.getUploadedAt());
	}

	@Test
	void emptyUploadIsRejected() throws Exception {
		MockMultipartFile emptyFile = new MockMultipartFile(
				"file", "empty.txt", MediaType.TEXT_PLAIN_VALUE, new byte[0]);

		mockMvc.perform(multipart("/upload").file(emptyFile))
				.andExpect(status().isBadRequest())
				.andExpect(jsonPath("$.message").value("The uploaded file must not be empty."));
		org.junit.jupiter.api.Assertions.assertEquals(0, metadataRepository.count());
	}

	@Test
	void unsafeFilenameIsRejected() throws Exception {
		MockMultipartFile unsafeFile = new MockMultipartFile(
				"file", "../unsafe.txt", MediaType.TEXT_PLAIN_VALUE, "unsafe".getBytes());

		mockMvc.perform(multipart("/upload").file(unsafeFile))
				.andExpect(status().isBadRequest())
				.andExpect(jsonPath("$.message").value("The uploaded filename is not valid."));
		org.junit.jupiter.api.Assertions.assertEquals(0, metadataRepository.count());
	}

}
