package com.example.healthcheck.upload;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;

@Entity
@Table(name = "FILE_METADATA",
		uniqueConstraints = @UniqueConstraint(
				name = "UK_FILE_METADATA_FILENAME",
				columnNames = "FILENAME"))
public class FileMetadata {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(name = "FILENAME", nullable = false, length = 255)
	private String filename;

	@Column(name = "CONTENT_TYPE", length = 255)
	private String contentType;

	@Column(name = "FILE_SIZE", nullable = false)
	private long sizeBytes;

	@Column(name = "STORAGE_PATH", nullable = false, length = 1000)
	private String storagePath;

	@Column(name = "UPLOADED_AT", nullable = false)
	private LocalDateTime uploadedAt;

	protected FileMetadata() {
	}

	public Long getId() {
		return id;
	}

	public String getFilename() {
		return filename;
	}

	public void setFilename(String filename) {
		this.filename = filename;
	}

	public String getContentType() {
		return contentType;
	}

	public void setContentType(String contentType) {
		this.contentType = contentType;
	}

	public long getSizeBytes() {
		return sizeBytes;
	}

	public void setSizeBytes(long sizeBytes) {
		this.sizeBytes = sizeBytes;
	}

	public String getStoragePath() {
		return storagePath;
	}

	public void setStoragePath(String storagePath) {
		this.storagePath = storagePath;
	}

	public LocalDateTime getUploadedAt() {
		return uploadedAt;
	}

	public void setUploadedAt(LocalDateTime uploadedAt) {
		this.uploadedAt = uploadedAt;
	}
}
