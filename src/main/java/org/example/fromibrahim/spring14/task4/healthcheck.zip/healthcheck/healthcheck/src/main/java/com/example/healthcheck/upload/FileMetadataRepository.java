package com.example.healthcheck.upload;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

public interface FileMetadataRepository extends JpaRepository<FileMetadata, Long> {

	Optional<FileMetadata> findByFilename(String filename);
}
