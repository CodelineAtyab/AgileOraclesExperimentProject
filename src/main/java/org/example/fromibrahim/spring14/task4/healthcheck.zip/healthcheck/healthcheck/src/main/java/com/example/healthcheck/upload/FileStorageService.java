package com.example.healthcheck.upload;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.InvalidPathException;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

@Service
public class FileStorageService {

	private final Path uploadDirectory;

	public FileStorageService(@Value("${app.upload.directory:uploaded_files}") String uploadDirectory) {
		this.uploadDirectory = Path.of(uploadDirectory).toAbsolutePath().normalize();
	}

	public StorageResult store(MultipartFile file, boolean overwrite) throws IOException {
		if (file.isEmpty()) {
			throw new IllegalArgumentException("The uploaded file must not be empty.");
		}

		String filename = validateFilename(file.getOriginalFilename());
		Path destination = uploadDirectory.resolve(filename).normalize();
		if (!destination.startsWith(uploadDirectory)) {
			throw new IllegalArgumentException("The uploaded filename is not valid.");
		}

		Files.createDirectories(uploadDirectory);
		boolean existed = Files.exists(destination);

		try (InputStream inputStream = file.getInputStream()) {
			if (overwrite) {
				Files.copy(inputStream, destination, StandardCopyOption.REPLACE_EXISTING);
			} else {
				Files.copy(inputStream, destination);
			}
		}

		return new StorageResult(filename, destination.toString(), overwrite && existed);
	}

	private String validateFilename(String originalFilename) {
		if (originalFilename == null || originalFilename.isBlank()) {
			throw new IllegalArgumentException("The uploaded filename is not valid.");
		}

		if (originalFilename.contains("/") || originalFilename.contains("\\")) {
			throw new IllegalArgumentException("The uploaded filename is not valid.");
		}

		try {
			Path filename = Path.of(originalFilename);
			if (filename.getNameCount() != 1 || filename.equals(Path.of(".")) || filename.equals(Path.of(".."))) {
				throw new IllegalArgumentException("The uploaded filename is not valid.");
			}
		} catch (InvalidPathException exception) {
			throw new IllegalArgumentException("The uploaded filename is not valid.", exception);
		}

		return originalFilename;
	}

	public record StorageResult(String filename, String storagePath, boolean overwritten) {
	}
}
