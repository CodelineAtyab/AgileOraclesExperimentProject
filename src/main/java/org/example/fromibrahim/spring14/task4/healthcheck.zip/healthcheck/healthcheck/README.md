# Spring Boot File Upload with Oracle Free

## What This Application Does

The application provides:

- `GET /health` to check that the API is running.
- `POST /upload` to upload a file.
- `POST /upload?overwrite=true` to confirm replacing an existing filename.

Uploaded file contents are stored in the Windows `shared_upload_files` folder through a Docker bind mount. File metadata is stored in the Oracle table `FILE_METADATA`.

The metadata includes the filename, content type, size, storage path, and latest upload time.

## 1. Enter Your Local Database Values

Copy the provided template:

```powershell
Copy-Item .env.example .env
```

Open `.env` and replace the two password placeholders:

```dotenv
ORACLE_PASSWORD=choose_your_oracle_admin_password
DB_USERNAME=FILE_APP
DB_PASSWORD=choose_your_application_password
```

- `ORACLE_PASSWORD` is the password for Oracle `SYS` and `SYSTEM`.
- `DB_USERNAME` is the application’s Oracle schema name. You can keep `FILE_APP`.
- `DB_PASSWORD` is the password used by the Spring Boot API.

Do not type the example placeholder values literally. Choose your own local passwords and do not commit `.env`.

For easier SQL*Plus testing, use passwords containing at least 12 letters and numbers, without spaces, `/`, `@`, `:`, or `#`.

## 2. Run the Automated Tests

```powershell
.\mvnw.cmd test
```

The tests use an in-memory H2 database, so Oracle does not need to be running.

## 3. Start the API and Oracle

Make sure Docker Desktop is running, then execute:

```powershell
docker compose up --build -d
```

The first Oracle startup can take several minutes.

Check both containers:

```powershell
docker compose ps
```

Follow Oracle startup logs:

```powershell
docker compose logs -f oracle-db
```

Wait until the logs contain:

```text
DATABASE IS READY TO USE!
```

Press `Ctrl+C` to stop following logs. The containers will continue running. The API starts only after Oracle becomes healthy.

## 4. Test the Health API

```powershell
curl.exe http://localhost:8000/health
```

Expected response:

```text
healthy
```

## 5. Upload a File with Postman

Create this request:

```text
POST http://localhost:8000/upload
```

In Postman:

1. Open **Body**.
2. Select **form-data**.
3. Add a key named `file`.
4. Change its type to **File**.
5. Select a file and click **Send**.

Expected response:

```json
{
  "message": "The file was uploaded successfully.",
  "filename": "example.txt",
  "overwriteRequired": false
}
```

## 6. Check the Uploaded File

Check the Windows bind-mount folder:

```powershell
Get-ChildItem .\shared_upload_files
```

Check the same directory inside the API container:

```powershell
docker exec healthcheckapp ls -la /app/uploaded_files
```

## 7. Check the Metadata in Oracle

Open SQL*Plus inside the Oracle container:

```powershell
docker exec -it app-container sqlplus FILE_APP/YOUR_DB_PASSWORD@//localhost:1521/FREEPDB1
```

Replace `YOUR_DB_PASSWORD` with the `DB_PASSWORD` value you entered in `.env`.

At the `SQL>` prompt, run:

```sql
SELECT ID, FILENAME, CONTENT_TYPE, FILE_SIZE, STORAGE_PATH, UPLOADED_AT
FROM FILE_METADATA;
```

Exit SQL*Plus:

```sql
EXIT;
```

## 8. Test Duplicate and Overwrite Behaviour

Upload the same filename again to:

```text
POST http://localhost:8000/upload
```

The API returns HTTP `409` and keeps the original file and metadata.

To confirm replacement, resend it to:

```text
POST http://localhost:8000/upload?overwrite=true
```

The existing file is replaced and its metadata row is updated.

## 9. Verify Oracle Is Not Exposed to Windows

```powershell
docker port app-container
```

The command should print nothing. The API reaches Oracle through Docker’s internal `app-network` using hostname `oracle-db`.

## 10. Stop the Application

```powershell
docker compose down
```

This preserves the Oracle named volume and the Windows uploaded files.

Do not run `docker compose down -v` unless you intentionally want to delete all Oracle metadata and create a fresh database.

## Existing Container Name Conflict

If Docker reports that `healthcheckapp` is already in use, inspect the old container:

```powershell
docker ps -a --filter "name=healthcheckapp"
```

If you no longer need it, stop and remove it before starting Compose:

```powershell
docker stop healthcheckapp
docker rm healthcheckapp
```
