package om.app.simpleform.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

@RestController
public class FormController {

    // Your old health endpoint
    @GetMapping("/health")
    public ResponseEntity<String> health() {
        return ResponseEntity.ok("OK");
    }


    // New upload endpoint
    @PostMapping("/upload")
    public ResponseEntity<String> uploadFile(
            @RequestParam("file") MultipartFile file) {

        try {
            Path uploadDirectory = Paths.get("uploaded_files");

            // Create uploaded_files if it doesn't exist
            if (!Files.exists(uploadDirectory)) {
                Files.createDirectories(uploadDirectory);
            }

            // Save the uploaded file
            Path filePath = uploadDirectory.resolve(file.getOriginalFilename());
            file.transferTo(filePath);

            return ResponseEntity.ok("File uploaded successfully");

        } catch (IOException e) {
            return ResponseEntity
                    .internalServerError()
                    .body("File upload failed");
        }
    }
}