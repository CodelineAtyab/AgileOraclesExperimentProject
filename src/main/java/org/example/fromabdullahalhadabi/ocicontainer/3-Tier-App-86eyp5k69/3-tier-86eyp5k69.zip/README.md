# Health Check App

Minimal Spring Boot 3.3.x app that exposes `GET /health` and returns `OK`.

## Run locally

```powershell
./mvnw.cmd clean install
java -jar target/demo-0.0.1-SNAPSHOT.jar
curl.exe http://localhost:8080/health
```

## Docker

```powershell
docker build -t my-health-app:0.0.1 .
docker run --rm -p 8080:8080 my-health-app:0.0.1
curl.exe http://localhost:8080/health
```

## Compose

```powershell
docker compose up -d
curl.exe http://localhost:8000/health
```

## 3-Tier Compose: API + Oracle Free DB

Docker Compose now runs two services:

- `db`: Oracle Free 23c on the internal Compose network only. It has no `ports:` mapping in the final compose file.
- `api`: Spring Boot on `localhost:8000`, connected to Oracle through the internal hostname `db`.

The API waits for Oracle to become healthy before starting:

```yaml
depends_on:
  db:
    condition: service_healthy
```

Oracle data is stored in the named Docker volume `oracle-data`, so metadata survives container recreation. `JPA_DDL_AUTO=update` lets Hibernate create/update the `UPLOAD_METADATA` table automatically. This project uses `SYSTEM` for assignment simplicity; a dedicated app user should be used for production.

Run everything:

```powershell
cd "C:\Users\OMEN\Downloads\CodeLine\health endpoint"
$env:ORACLE_PASSWORD = "ChangeMe123"
./mvnw.cmd clean install
docker compose up -d --build
docker compose ps
```

On first Oracle initialization, wait 1-3 minutes for the `db` service to become healthy:

```powershell
Start-Sleep -Seconds 60
docker compose ps
```

Upload a file and expect JSON containing `metadataId`:

```powershell
curl.exe -F "file=@test.txt" http://localhost:8000/api/upload
dir shared_upload_files
```

Verify metadata without exposing the database port:

```powershell
docker exec oracle-db bash -c "echo 'SELECT ID, FILENAME, FILE_SIZE, CONTENT_TYPE, STORED_PATH, UPLOADED_AT FROM UPLOAD_METADATA;' | sqlplus -s SYSTEM/ChangeMe123@//localhost:1521/FREEPDB1"
```

Verify named-volume persistence:

```powershell
docker compose down
docker compose up -d
docker exec oracle-db bash -c "echo 'SELECT COUNT(*) FROM UPLOAD_METADATA;' | sqlplus -s SYSTEM/ChangeMe123@//localhost:1521/FREEPDB1"
```

For DB Visualizer testing only, temporarily add `- "1521:1521"` under `db.ports`, connect to `localhost:1521/FREEPDB1`, then remove the port mapping before final acceptance.

## File Upload

The app accepts multipart file uploads at `POST /api/upload`. The multipart field name must be `file`.

## Mounting Directories - Task 86eynrhre

Spring Boot stores uploaded files inside the container at `/app/uploaded_files`. Docker Compose bind mounts the Windows project folder `shared_upload_files` to that container path:

```yaml
volumes:
  - ./shared_upload_files:/app/uploaded_files
```

Run and verify:

```powershell
docker compose up -d --build
curl.exe -s -o NUL -w "%{http_code}" http://localhost:8000/health
curl.exe -s -F "file=@test-upload.txt" http://localhost:8000/api/upload
dir shared_upload_files
docker exec healthcheck-container sh -c "ls -la /app/uploaded_files"
```

Empty file uploads return `400` with `{"error":"File is empty"}`.

### Commands Used For This Task

Run these commands from the project folder:

```powershell
cd "C:\Users\OMEN\Downloads\CodeLine\health endpoint"
```

Build the Spring Boot app:

```powershell
mvn clean install
```

Start the app with Docker Compose and rebuild the image:

```powershell
docker compose up -d --build --force-recreate
```

Wait for the app to start:

```powershell
Start-Sleep -Seconds 12
```

Check the health endpoint:

```powershell
curl.exe -s -o NUL -w "%{http_code}" http://localhost:8000/health
```

Create a test file:

```powershell
echo "hello from windows" > test-upload.txt
```

Upload the file:

```powershell
curl.exe -s -F "file=@test-upload.txt" http://localhost:8000/api/upload
```

Check that the uploaded file appears on Windows:

```powershell
dir shared_upload_files
```

Check that the uploaded file appears inside the container:

```powershell
docker exec healthcheck-container ls -la /app/uploaded_files
```

Prove the bind mount works from Windows to container:

```powershell
echo "from windows 2" > shared_upload_files/second.txt
docker exec healthcheck-container ls /app/uploaded_files
```

Test empty-file rejection:

```powershell
New-Item -ItemType File -Force empty.txt
curl.exe -s -w "`n%{http_code}" -X POST -F "file=@empty.txt" http://localhost:8000/api/upload
```

```powershell
echo "hello from windows" > test-upload.txt
curl.exe -s -F "file=@test-upload.txt" http://localhost:8000/api/upload
```

Expected response:

```json
{"filename":"test-upload.txt","size":20,"storedPath":"uploaded_files/test-upload.txt"}
```

Empty files are rejected:

```powershell
New-Item -ItemType File -Force empty.txt
curl.exe -s -X POST -F "file=@empty.txt" http://localhost:8000/api/upload
```

Expected response:

```json
{"error":"File is empty"}
```

Saved files can also be listed:

```powershell
curl.exe -s http://localhost:8000/api/uploaded
```

### Bind Mount Volume

Docker Compose mounts the Windows project folder `shared_upload_files` into the container at `/app/uploaded_files`:

```yaml
volumes:
  - ./shared_upload_files:/app/uploaded_files
```

Because this is a bind mount, files written by Spring Boot inside the container appear in `shared_upload_files` on Windows, and files added to `shared_upload_files` on Windows appear inside `/app/uploaded_files` in the container.

Docker run equivalent:

```powershell
docker run -d -p 8000:8080 -v "${PWD}/shared_upload_files:/app/uploaded_files" --name healthcheck-container healthcheck-app
```

### End-to-End Verification

```powershell
./mvnw.cmd clean install
docker compose up -d --build --force-recreate
Start-Sleep -Seconds 12
curl.exe -s -o NUL -w "%{http_code}" http://localhost:8000/health

echo "hello from windows" > test-upload.txt
curl.exe -s -F "file=@test-upload.txt" http://localhost:8000/api/upload

dir shared_upload_files
docker exec healthcheck-container ls -la /app/uploaded_files

echo "from windows 2" > shared_upload_files/second.txt
docker exec healthcheck-container ls /app/uploaded_files
```

### Postman

Use `POST http://localhost:8000/api/upload`, then set Body to `form-data`. Add key `file`, change its type to `File`, choose a file, and send the request. A successful upload returns JSON with `filename`, `size`, `storedPath`, and `metadataId`; the file should appear in `shared_upload_files` on Windows.

## Docker Hub note

Replace `my-health-app:0.0.1` with your Docker Hub repository name before publishing.
