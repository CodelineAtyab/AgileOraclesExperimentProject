package com.example.demo;

import org.springframework.data.jpa.repository.JpaRepository;

public interface UploadMetadataRepository extends JpaRepository<UploadMetadata, Long> {
}
