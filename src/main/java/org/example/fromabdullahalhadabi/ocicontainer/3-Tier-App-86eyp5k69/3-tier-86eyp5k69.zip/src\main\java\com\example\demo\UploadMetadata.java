package com.example.demo;

import java.time.Instant;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "UPLOAD_METADATA")
public class UploadMetadata {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String filename;

    @Column(name = "FILE_SIZE", nullable = false)
    private long size;

    private String contentType;

    @Column(nullable = false)
    private String storedPath;

    @Column(nullable = false)
    private Instant uploadedAt;

    protected UploadMetadata() {
    }

    public UploadMetadata(String filename, long size, String contentType, String storedPath, Instant uploadedAt) {
        this.filename = filename;
        this.size = size;
        this.contentType = contentType;
        this.storedPath = storedPath;
        this.uploadedAt = uploadedAt;
    }

    public Long getId() {
        return id;
    }

    public String getFilename() {
        return filename;
    }

    public long getSize() {
        return size;
    }

    public String getContentType() {
        return contentType;
    }

    public String getStoredPath() {
        return storedPath;
    }

    public Instant getUploadedAt() {
        return uploadedAt;
    }
}
