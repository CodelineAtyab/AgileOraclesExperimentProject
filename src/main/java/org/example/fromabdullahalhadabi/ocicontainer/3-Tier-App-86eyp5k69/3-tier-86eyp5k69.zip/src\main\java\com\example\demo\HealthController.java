package com.example.demo;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Instant;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;

@RestController
public class HealthController {

    private static final Logger LOGGER = LoggerFactory.getLogger(HealthController.class);
    private static final Path UPLOAD_DIR = Path.of("uploaded_files");

    private final UploadMetadataRepository uploadMetadataRepository;

    public HealthController(UploadMetadataRepository uploadMetadataRepository) {
        this.uploadMetadataRepository = uploadMetadataRepository;
    }

    @GetMapping("/health")
    public String health() {
        return "OK";
    }

    @PostMapping("/api/upload")
    public ResponseEntity<Map<String, Object>> upload(@RequestParam("file") MultipartFile file) throws IOException {
        if (file.isEmpty()) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(Map.of("error", "File is empty"));
        }

        Files.createDirectories(UPLOAD_DIR);

        String originalFilename = file.getOriginalFilename();
        String filename = StringUtils.hasText(originalFilename) ? Path.of(originalFilename).getFileName().toString() : "upload";
        Path destination = UPLOAD_DIR.resolve(filename);
        file.transferTo(destination);
        String storedPath = UPLOAD_DIR.resolve(filename).toString().replace('\\', '/');

        UploadMetadata metadata = new UploadMetadata(
                filename,
                file.getSize(),
                file.getContentType(),
                storedPath,
                Instant.now()
        );

        try {
            metadata = uploadMetadataRepository.save(metadata);
        } catch (DataAccessException ex) {
            LOGGER.error("Failed to persist upload metadata for {}", filename, ex);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(Map.of(
                    "error", "File saved but metadata persistence failed"
            ));
        }

        return ResponseEntity.ok(Map.of(
                "filename", filename,
                "size", file.getSize(),
                "storedPath", storedPath,
                "metadataId", metadata.getId()
        ));
    }

    @GetMapping("/api/uploaded")
    public List<String> uploadedFiles() throws IOException {
        if (!Files.exists(UPLOAD_DIR)) {
            return List.of();
        }

        try (var files = Files.list(UPLOAD_DIR)) {
            return files
                    .filter(Files::isRegularFile)
                    .map(path -> path.getFileName().toString())
                    .sorted()
                    .toList();
        }
    }
}
