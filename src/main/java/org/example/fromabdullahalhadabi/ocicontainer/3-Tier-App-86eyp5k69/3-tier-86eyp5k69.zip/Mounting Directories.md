# Mounting Directories - Docker Bind Mount (Task 86eynrhre)

## Flow
1. Spring Boot uploads files into container path: `/app/uploaded_files`
2. Windows shared folder: `<project>/shared_upload_files`
3. Docker bind mount maps them: `-v <project>/shared_upload_files:/app/uploaded_files`
4. Acceptance test: upload via Postman or curl, then verify the file appears in both the Windows folder and the container.

## Commands
- Build and run: `docker compose up -d --build`
- Upload: `curl -F "file=@test.txt" http://localhost:8000/api/upload`
- Check Windows: `dir shared_upload_files`
- Check container: `docker exec healthcheck-container sh -c "ls -la /app/uploaded_files"`
- Empty file upload returns `400`

## Why
Containers are ephemeral; bind mounts keep data on the host and survive container removal or restart. This maps to OCI Container Instances ephemeral storage, where volumes matter for persistent uploaded files.

## 3-Tier Upload Metadata

Uploaded files still use the bind mount:

```yaml
volumes:
  - ./shared_upload_files:/app/uploaded_files
```

Upload metadata is stored in Oracle Free DB in the `UPLOAD_METADATA` table. Compose runs Oracle and the API together:

- `db` uses `gvenzl/oracle-free:23-slim`.
- `api` connects to `jdbc:oracle:thin:@db:1521/FREEPDB1`.
- `db` has no exposed host ports in the final compose file.
- `depends_on.condition: service_healthy` keeps the API from starting until Oracle is healthy.
- `oracle-data` is a named volume so database rows survive `docker compose down` and `docker compose up`.

Run and verify:

```powershell
docker compose up -d --build
docker compose ps
curl.exe -F "file=@test.txt" http://localhost:8000/api/upload
docker exec oracle-db bash -c "echo 'SELECT COUNT(*) FROM UPLOAD_METADATA;' | sqlplus -s SYSTEM/ChangeMe123@//localhost:1521/FREEPDB1"
```

The API returns `500` if the file is saved but metadata persistence fails. That keeps upload acceptance tied to database persistence instead of silently losing the metadata record.
