# Health Check App

Minimal Spring Boot 3.3.x app that exposes `GET /health` and returns `OK`.

## Run locally

```powershell
./mvnw.cmd clean install
java -jar target/demo-0.0.1-SNAPSHOT.jar
curl.exe http://localhost:8080/health
```

## Docker

```powershell
docker build -t my-health-app:0.0.1 .
docker run --rm -p 8080:8080 my-health-app:0.0.1
curl.exe http://localhost:8080/health
```

## Compose

```powershell
docker compose up -d
curl.exe http://localhost:8000/health
```

## Docker Hub note

Replace `my-health-app:0.0.1` with your Docker Hub repository name before publishing.
