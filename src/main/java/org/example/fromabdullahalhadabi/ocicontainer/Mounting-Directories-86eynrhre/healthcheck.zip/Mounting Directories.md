# Mounting Directories - Docker Bind Mount (Task 86eynrhre)

## Flow
1. Spring Boot uploads files into container path: `/app/uploaded_files`
2. Windows shared folder: `<project>/shared_upload_files`
3. Docker bind mount maps them: `-v <project>/shared_upload_files:/app/uploaded_files`
4. Acceptance test: upload via Postman or curl, then verify the file appears in both the Windows folder and the container.

## Commands
- Build and run: `docker compose up -d --build`
- Upload: `curl -F "file=@test.txt" http://localhost:8000/api/upload`
- Check Windows: `dir shared_upload_files`
- Check container: `docker exec healthcheck-container sh -c "ls -la /app/uploaded_files"`
- Empty file upload returns `400`

## Why
Containers are ephemeral; bind mounts keep data on the host and survive container removal or restart. This maps to OCI Container Instances ephemeral storage, where volumes matter for persistent uploaded files.
