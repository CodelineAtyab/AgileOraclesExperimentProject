package com.example.demo;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Map;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;

@RestController
public class HealthController {

    private static final Path UPLOAD_DIR = Path.of("uploaded_files");

    @GetMapping("/health")
    public String health() {
        return "OK";
    }

    @PostMapping("/api/upload")
    public ResponseEntity<Map<String, Object>> upload(@RequestParam("file") MultipartFile file) throws IOException {
        if (file.isEmpty()) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(Map.of("error", "File is empty"));
        }

        Files.createDirectories(UPLOAD_DIR);

        String originalFilename = file.getOriginalFilename();
        String filename = StringUtils.hasText(originalFilename) ? Path.of(originalFilename).getFileName().toString() : "upload";
        Path destination = UPLOAD_DIR.resolve(filename);
        file.transferTo(destination);

        return ResponseEntity.ok(Map.of(
                "filename", filename,
                "size", file.getSize(),
                "storedPath", UPLOAD_DIR.resolve(filename).toString().replace('\\', '/')
        ));
    }

    @GetMapping("/api/uploaded")
    public List<String> uploadedFiles() throws IOException {
        if (!Files.exists(UPLOAD_DIR)) {
            return List.of();
        }

        try (var files = Files.list(UPLOAD_DIR)) {
            return files
                    .filter(Files::isRegularFile)
                    .map(path -> path.getFileName().toString())
                    .sorted()
                    .toList();
        }
    }
}
