# Health Check App

Minimal Spring Boot application that exposes `GET /health` and returns `OK`.

## Run locally

```bash
./mvnw.cmd clean install
java -jar target/demo-0.0.1-SNAPSHOT.jar
curl http://localhost:8080/health
```

## Docker

```bash
docker build -t my-health-app:0.0.1 .
docker run --rm -p 8080:8080 my-health-app:0.0.1
curl http://localhost:8080/health
```

## Compose

```bash
docker compose up -d
curl http://localhost:8000/health
```

## Docker Hub

Replace `my-health-app:0.0.1` with your Docker Hub repository name when you are ready to publish the image.
