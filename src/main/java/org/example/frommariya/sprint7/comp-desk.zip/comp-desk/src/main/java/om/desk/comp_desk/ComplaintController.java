package om.desk.comp_desk;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


import java.time.LocalDateTime;
import java.util.*;
import java.util.concurrent.atomic.AtomicLong;

@RestController
@RequestMapping(path="/complaints")
public class ComplaintController {



    //In Memory Storage
    private final Map<Long,Complaint> complaintStore=new HashMap<>();
    private final AtomicLong idCounter=new AtomicLong(1);

    //Register New Complaint (POST):
    @PostMapping
    public ResponseEntity<Complaint> createComplaints(@RequestBody Complaint complaint){
        long id = idCounter.getAndIncrement();
        complaint.setId(id);
        complaint.setCreatedAt(LocalDateTime.now().toString());

        complaintStore.put(id,complaint);
        return
                ResponseEntity.status(HttpStatus.CREATED).body(complaint);

    }


    //List All Complaints (GET)
    @GetMapping
    public List<Complaint> getAllComplaints(){
        return
                new ArrayList<>(complaintStore.values());
    }

    // Get Specific Complaint by ID (GET)
    @GetMapping("/{id}")
    public ResponseEntity<Complaint> getComplaintById(@PathVariable Long id){
        if(complaintStore.containsKey(id)){
            return
                    ResponseEntity.ok(complaintStore.get(id));
        }
        return
                ResponseEntity.status(HttpStatus.NOT_FOUND).build();
    }


    // Remove a Complaint (DELETE)
    @DeleteMapping("/{id}")
    public ResponseEntity<Map<String,String>> deleteComplaint(@PathVariable Long id){
        if(complaintStore.containsKey(id)){
            complaintStore.remove(id);
            Map<String,String> response =new HashMap<>();
            response.put("message","Complaint with id " +id +" has been deleted successfully.");
            return
                    ResponseEntity.ok(response);
        }
        return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
    }
    
}
