package om.desk.comp_desk;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CompDeskApplicationTests {

	@Test
	void contextLoads() {
	}

}
