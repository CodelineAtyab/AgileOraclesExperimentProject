package om.desk.comp_desk;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CompDeskApplication {

	public static void main(String[] args) {
		SpringApplication.run(CompDeskApplication.class, args);
	}

}
