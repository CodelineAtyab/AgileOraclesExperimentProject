package om.desk.comp_desk;

public class Complaint {
    private Long id;
    private String title;
    private String description;
    private String submittedBy;
    private String createdAt;

    public Complaint(){}

    public Complaint(Long id, String title, String description, String submittedBy, String createdAt ){
        this.id=id;
        this.title=title;
        this.description=description;
        this.submittedBy=submittedBy;
        this.createdAt=createdAt;
    }

    public Long getId(){
        return id;
    }

    public void setId(Long id){
        this.id=id;
    }



    public String getTitle(){
        return title;
    }

    public void setTitle(String title){
        this.title=title;
    }



    public String getDescription(){
        return description;
    }

    public void setDescription(String description){
        this.description=description;
    }



    public String getSubmittedBy(){
        return submittedBy;
    }

    public void setSubmittedBy(String submittedBy){
        this.submittedBy=submittedBy;
    }



    public String getCreatedAt(){
        return createdAt;
    }

    public void setCreatedAt(String createdAt){
        this.createdAt=createdAt;
    }

}
